from matplotlib import pyplot

# was it really this simple or am I missing something?
def main():    
    pyplot.bar(1, 160, color = 'orangered')
    pyplot.bar(2,250, color = 'lime')
    pyplot.bar(3,60, color = 'mediumblue')
    pyplot.show()
    
main()